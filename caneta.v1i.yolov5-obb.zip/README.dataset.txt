# caneta > 2024-03-05 8:03pm
https://universe.roboflow.com/jorge-marquesferreira-junior-xfeck/caneta

Provided by a Roboflow user
License: CC BY 4.0

